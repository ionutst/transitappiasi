var express = require('express');
var app = express();
var fs = require('fs');
var bodyParser = require('body-parser')
	app.use( bodyParser.json() );       // to support JSON-encoded bodies
	app.use(bodyParser.urlencoded({     // to support URL-encoded bodies
	extended: true
})); 

var pathJson = JSON.parse(fs.readFileSync('pathJson.json', 'utf8'));

app.set('port', (process.env.PORT || 5000));

app.use(express.static(__dirname + '/public'));

//app.use(express.json());       // to support JSON-encoded bodies
//app.use(express.urlencoded());

// views is directory for all template files
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');

app.get('/', function(request, response) {
  response.render('pages/index');
});

app.get('/realtime', function(request, response) {
	var i = request.query.iteration;
	response.writeHead(200, {"Content-Type": "application/json"});
	response.end(generateJson(i));
});

app.post('/stopShare', function(request, response) {
	console.log('will stop share');
	cleanDb();
    response.writeHead(200, {"Content-Type": "application/json"});
	response.end(JSON.stringify({response:"Stoped sharing"}))
});

app.post('/shareLocation', function(request, response) {
	console.log(request.body);
	var json = request.body;
	writeJsonToDb(json);
	response.writeHead(200, {"Content-Type": "application/json"});
	response.end(JSON.stringify({response:"Thank you for sharing"}))
});

app.listen(app.get('port'), function() {
  console.log('Node app is running on port', app.get('port'));
});

function generateJson(i){
	
	i = i%pathJson.length;
	var ii = (i + 1)%pathJson.length;
	console.log('generateJson '+i + ','+ii);

	var bus1 = {"label":"1",
		"type":"T",
		"lat":pathJson[i].lat,
		"lng":pathJson[i].lng,
		"status":"green"};
	var bus41 = {"label":"41",
		"type":"B",
		"lat":pathJson[ii].lat,
		"lng":pathJson[ii].lng,
		"status":"orange"};
	var jsonObj = [bus1,bus41];
	var db = readDb();
	var merge = jsonObj.concat(db);
	var json = JSON.stringify(merge);
	return json;
}

function readDb(){
	console.log('reading the database');
	var db = JSON.parse(fs.readFileSync('db.json', 'utf8'));
	return db;
}

function writeJsonToDb(json){
	var db = readDb();
	db.push(json);
	fs.writeFile("db.json", JSON.stringify(db), function(err) {
		if(err) {
			console.log(err);
		}

		console.log("The file was saved!");
	}); 
}

function cleanDb(){
	console.log('try cleaning up the database');
	fs.writeFile("db.json", JSON.stringify([]), function(err) {
		if(err) {
			console.log(err);
		}

		console.log("databased cleaned!");
	}); 
}



